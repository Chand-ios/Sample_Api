//
//  ViewController.swift
//  PrahemTest
//
//  Created by Mac on 06/10/20.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var pswrdTxtFld: UITextField!
    @IBOutlet weak var emailTxtfld: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        loginBtn.layer.cornerRadius = 20
        loginBtn.clipsToBounds = true
        
        emailTxtfld.delegate = self
        pswrdTxtFld.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        emailTxtfld.resignFirstResponder()
        pswrdTxtFld.resignFirstResponder()
        return true
    }

    @IBAction func loginAction(_ sender: Any) {
        self.view.endEditing(true)

        if emailTxtfld.text == ""{
            self.showToast(message: "Enter Email", font: .systemFont(ofSize: 12.0))

            return
        }
        else if pswrdTxtFld.text == ""{
            self.showToast(message: "Enter Password", font: .systemFont(ofSize: 12.0))
            return
        }
        
        else{
        
        let homeVC = self.storyboard?.instantiateViewController(identifier: "HomeViewController") as! HomeViewController
            UserDefaults.standard.set(self.emailTxtfld.text!, forKey: "email")
            UserDefaults.standard.set(self.pswrdTxtFld.text!, forKey: "password")
        self.navigationController?.pushViewController(homeVC, animated: true)
    }
        
    }
    
}

extension UIViewController {

func showToast(message : String, font: UIFont) {

    let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
    toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    toastLabel.textColor = UIColor.white
    toastLabel.font = font
    toastLabel.textAlignment = .center;
    toastLabel.text = message
    toastLabel.alpha = 1.0
    toastLabel.layer.cornerRadius = 10;
    toastLabel.clipsToBounds  =  true
    self.view.addSubview(toastLabel)
    UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
         toastLabel.alpha = 0.0
    }, completion: {(isCompleted) in
        toastLabel.removeFromSuperview()
    })
} }

