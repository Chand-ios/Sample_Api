//
//  ColorModel.swift
//  CollectionViewInsideTableViewExample
//
//  Created by John Codeos on 12/21/19.
//  Copyright © 2019 John Codeos. All rights reserved.
//

import Foundation
import UIKit

struct CollectionViewCellModel {
    let category : String
    let priority : Int
    let description : String
    let iconpicurl : String
    let innerpicurl : String
    let displaypicurl : String
    let carousalpicurl : String
}
