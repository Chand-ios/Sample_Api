//
//  CategoryModel.swift
//  PrahemTest
//
//  Created by eAlphaMac2 on 06/10/20.
//

import Foundation
struct CategoryModel {
    let details : [[String:Any]]?
    
    
}
